# Faker Documentation

This repository contains documentation for [FakerPHP / Faker](https://github.com/FakerPHP/Faker).

## License

Faker is released under the MIT license. See the bundled LICENSE file for details.
