# UUID

## `uuid`

Generate a random UUID.

```php
echo $faker->uuid();

// 'bf91c434-dcf3-3a4c-b49a-12e0944ef1e2', '5b2c0654-de5e-3153-ac1f-751cac718e4e'
```
