# Romanian (Moldova)

### `Faker\Provider\ro_MD\Payment`

```php
// Generates a random bank account number
echo $faker->bankAccountNumber(); // "MD83BQW1CKMUW34HBESDP3A8"
```
