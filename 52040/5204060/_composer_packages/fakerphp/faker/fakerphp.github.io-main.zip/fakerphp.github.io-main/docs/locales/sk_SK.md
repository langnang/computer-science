# Slovak (Slovakia)

### `Faker\Provider\sk_SK\Payment`

```php
// Generates a random bank account number
echo $faker->bankAccountNumber(); // "SK6413578310194914530894"
```
