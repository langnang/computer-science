# Lithuanian (Lithuania)

### `Faker\Provider\lt_LT\Payment`

```php
echo $faker->bankAccountNumber(); // "LT300848876740317118"
```
