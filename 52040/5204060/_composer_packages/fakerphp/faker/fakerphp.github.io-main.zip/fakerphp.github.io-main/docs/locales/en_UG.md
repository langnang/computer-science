# English (Uganda)

### `Faker\Provider\en_UG\Address`

```php
echo $faker->district(); // "Kabarole"
echo $faker->region();   // "North"
```
