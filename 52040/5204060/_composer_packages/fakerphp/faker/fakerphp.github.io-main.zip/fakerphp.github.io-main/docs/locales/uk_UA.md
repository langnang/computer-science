# Ukrainian (Ukraine)

### `Faker\Provider\uk_UA\Payment`

```php
// Generates an Ukraine bank name (based on list of real Ukraine banks)
echo $faker->bank(); // "Ощадбанк"
```
