# Georgian (Georgia)

### `Faker\Provider\ka_GE\Payment`

```php
// Generates a random bank account number
echo $faker->bankAccountNumber(); // "GE33ZV9773853617253389"
```
