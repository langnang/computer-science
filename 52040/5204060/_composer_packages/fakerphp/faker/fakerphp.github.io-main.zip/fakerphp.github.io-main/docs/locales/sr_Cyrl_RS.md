# Serbian (Cyrillic, Serbia)

### `Faker\Provider\sr_Cyrl_RS\Payment`

```php
// Generates a random bank account number
echo $faker->bankAccountNumber(); // "RS67272104347913868782"
```
