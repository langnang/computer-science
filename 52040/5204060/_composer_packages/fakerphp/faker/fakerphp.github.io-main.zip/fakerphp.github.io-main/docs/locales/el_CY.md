# Greek (Cyprus)

### `Faker\Provider\el_CY\Payment`

```php
echo $faker->bankAccountNumber(); // "CY52603169440XP3ZL20NAZ084I1"
echo $faker->bank();              // "Societe Gererale Cyprus"
```

### `Faker\Provider\el_CY\PhoneNumber`

```php
echo $faker->mobileNumber(); // "93585791"
```
