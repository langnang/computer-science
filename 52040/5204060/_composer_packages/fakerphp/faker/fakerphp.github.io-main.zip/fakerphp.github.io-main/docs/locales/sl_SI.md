# Slovenian (Slovenia)

### `Faker\Provider\sl_SI\Payment`

```php
// Generates a random bank account number
echo $faker->bankAccountNumber(); // "SI54033367976489565"
```
