# Chinese (Simplified, China)

### `Faker\Provider\zh_CN\Payment`

```php
// Generates a random bank name (based on list of real chinese banks)
echo $faker->bank(); // '中国建设银行'
```
