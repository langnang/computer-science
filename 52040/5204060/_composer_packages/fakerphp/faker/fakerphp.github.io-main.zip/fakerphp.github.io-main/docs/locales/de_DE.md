# German (Germany)

### `Faker\Provider\de_DE\Payment`

```php
echo $faker->bankAccountNumber(); // "DE41849025553661169313"
echo $faker->bank(); // "Volksbank Stuttgart"
```
