# Serbian (Latin, Serbia)

### `Faker\Provider\sr_Latn_RS\Payment`

```php
// Generates a random bank account number
echo $faker->bankAccountNumber(); // "RS67272104347913868782"
```
