# Nepali (Nepal)

### `Faker\Provider\ne_NP\Address`

```php
// Generates a Nepali district name
echo $faker->district();

// Generates a Nepali city name
echo $faker->cityName();
```
