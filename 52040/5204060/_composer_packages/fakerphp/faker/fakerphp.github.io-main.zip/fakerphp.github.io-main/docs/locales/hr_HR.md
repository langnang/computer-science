# Croatian (Croatia)

### `Faker\Provider\hr_HR\Payment`

```php
echo $faker->bankAccountNumber(); // "HR3789114847226078672"
```
