# Bangla (Bangladesh)

### `Faker\Provider\bn_BD\Company`

```php
echo $faker->companyType(); // "সার"
```
