# English (Nigeria)

### `Faker\Provider\en_NG\Address`

```php
echo $faker->county(); // 'Edo'
echo $faker->region(); // 'Katsina'
```

### `Faker\Provider\en_NG\Person`

```php
// Generates a random person name
echo $faker->name(); // 'Oluwunmi Mayowa'
```
