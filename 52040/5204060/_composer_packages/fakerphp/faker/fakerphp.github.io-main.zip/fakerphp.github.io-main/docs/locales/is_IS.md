# Icelandic (Iceland)

### `Faker\Provider\is_IS\Payment`

```php
echo $faker->bankAccountNumber(); // "IS772061465007570166313591"
```
