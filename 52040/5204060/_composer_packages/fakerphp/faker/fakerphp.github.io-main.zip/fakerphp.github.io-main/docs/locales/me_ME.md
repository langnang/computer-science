# Montenegrin (Montenegro)

### `Faker\Provider\me_ME\Payment`

```php
echo $faker->bankAccountNumber(); // "ME62304676623331330300"
```
