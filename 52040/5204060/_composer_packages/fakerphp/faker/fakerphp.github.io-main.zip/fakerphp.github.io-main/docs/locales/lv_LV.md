# Latvian (Latvia)

### `Faker\Provider\lv_LV\Payment`

```php
echo $faker->bankAccountNumber(); // "LV56XUHF3FI0W5413NIP0"
```

### `Faker\Provider\lv_LV\Person`

```php
// Generates a random personal identity card number
echo $faker->personalIdentityNumber(); // "140190-12301"
```
